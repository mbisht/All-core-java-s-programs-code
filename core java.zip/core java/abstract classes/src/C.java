
class C 
{
	abstract void test1();

}
