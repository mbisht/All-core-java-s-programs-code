
abstract class U 
{
	U()
	{
		System.out.println("Hello World!");
	}

}
