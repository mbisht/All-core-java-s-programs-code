
abstract class E 
{
	abstract void test1();
	{
		
	}

}
