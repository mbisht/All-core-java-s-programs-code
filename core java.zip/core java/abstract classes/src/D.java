
abstract class D 
{
	void test1();

}
