package pack1;

class O
{
	private O()
	{
		System.out.println("O()");
	}
}

class P {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		O o1=new O();
		System.out.println("done");

	}

}
