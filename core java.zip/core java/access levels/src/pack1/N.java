package pack1;

class N 
{
	private N()
	{
		System.out.println("N()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		N n1=new N();
		System.out.println("done");

	}

}
