package pack1;

class F 
{
	private int i=90;
	static void test()
	{
		System.out.println(i);	
	}
}
class G {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(F.i);

	}

}
