package pack1;

class U 
{
	private
	{
		
	}
	private static
	{
		
	}

}
