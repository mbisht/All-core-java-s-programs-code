package pack1;

class B
{
	private int i;
}
class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1=new B();
		System.out.println(b1.i);

	}

}

