package pack1;

class Q
{
	private Q()
	{
		System.out.println("Q()");
	}
}
class R extends Q{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("done");

	}

}
