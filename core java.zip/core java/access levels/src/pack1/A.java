package pack1;

class A 
{
	
		private int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new A();
		System.out.println(a1.i);

	}

}
