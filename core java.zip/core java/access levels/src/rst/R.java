package rst;

class R {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		lara.N n1=new lara.N();
		System.out.println("done");

	}

}
