package rst;

class M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		lara.F f1=new F();
		f1.test1();
		System.out.println("Hello World!");

	}

}
