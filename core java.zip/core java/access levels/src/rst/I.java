package rst;

class I extends H
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I i1=new I();
		System.out.println(i1.j);
		System.out.println(i1.k);

	}

}
