package rst;
import lara.N;


class V extends N{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		N n1=new N();
		N n2=new N();
		N n3=new N();
		N n4=new N();
		System.out.println("done");

	}

}
