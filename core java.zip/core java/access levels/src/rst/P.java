package rst;

class P extends lara.N{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		P p1=new P();
		System.out.println(p1.i);

	}

}
