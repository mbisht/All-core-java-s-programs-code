package rst;
import lara.N;
class S {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		N n1=new N();
		System.out.println("Hello World!");

	}

}
