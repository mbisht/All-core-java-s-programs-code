package rst;

class O {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		lara.N n1=new lara.N();
		System.out.println(n1.i);

	}

}
