package rst;

class M1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		G g1=new G();
		System.out.println(g1.j);
		System.out.println(g1.k);
		L l1=new L();
		System.out.println(l1.j);
		System.out.println(l1.k);

	}

}
