package rst;

class L {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		lara.A a1=new lara.A();
		System.out.println(a1.i);

	}

}
