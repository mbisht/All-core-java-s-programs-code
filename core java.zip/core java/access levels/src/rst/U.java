package rst;

class U extends lara.N{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		lara.N n1=new lara.N();
		lara.N n2=new lara.N();
		lara.N n3=new lara.N();
		System.out.println("done");

	}

}
