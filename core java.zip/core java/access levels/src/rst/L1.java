package rst;

class L1 extends I
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		L1 obj1=new L1();
		System.out.println(obj1.j);
		System.out.println(obj1.k);
		I obj2=new I();
		System.out.println(obj2.j);
		System.out.println(obj2.k);

	}

}
