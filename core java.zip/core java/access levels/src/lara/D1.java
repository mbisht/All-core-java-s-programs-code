package lara;

class D1 extends C{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		D1 d1=new D1();
		System.out.println(d1.i);
		System.out.println(d1.j);
		System.out.println(d1.k);

	}

}
