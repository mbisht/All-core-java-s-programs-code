package lara;

class E1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new A();
		System.out.println(a1.i);
		System.out.println(a1.j);
		System.out.println(a1.k);
		C c1=new C();
		System.out.println(c1.i);
		System.out.println(c1.j);
		System.out.println(c1.k);
		D d1=new D();
		System.out.println(d1.i);
		System.out.println(d1.j);
		System.out.println(d1.k);
	}

}
