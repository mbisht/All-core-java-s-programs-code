package lara;

class C2 extends A{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C2 c1=new C2();
		System.out.println(c1.i);
		System.out.println(c1.j);
		System.out.println(c1.k);

	}

}
