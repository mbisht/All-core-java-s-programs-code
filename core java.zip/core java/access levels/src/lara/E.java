package lara;

class E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new A();
		System.out.println(a1.i);
		C1 c1=new C1();
		System.out.println(c1.i);
		D d1=new D();
		System.out.println(d1.i);

	}

}

