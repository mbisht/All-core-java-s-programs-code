package lara;

class C1 extends A{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C1 c1=new C1();
		System.out.println(c1.i);

	}

}
