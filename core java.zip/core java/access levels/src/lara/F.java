package lara;

class F 
{
	void test1()
	{
		System.out.println("test1");
	}
}
