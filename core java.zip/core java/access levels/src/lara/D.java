package lara;

class D extends C1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		D d1=new D();
		System.out.println(d1.i);

	}

}
