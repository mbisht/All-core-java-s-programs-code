package lara;

class G {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		F f1=new F();
		f1.test1();
		System.out.println("done");

	}

}
