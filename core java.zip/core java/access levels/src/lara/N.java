package lara;

public class N 
{
	int i;

}
