package lara;

public class A1 
{
	int i;
	protected int j;
	public int k;

}
