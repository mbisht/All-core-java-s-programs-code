package lara;

class I extends H{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I i1=new I();
		i1.test1();
		System.out.println("Hello World!");

	}

}
