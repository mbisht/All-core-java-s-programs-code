
class M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte b=10;
		int i=b;
		int j=(int)b;
		double d1=i;
		double d2=(double)i;
		System.out.println("done");

	}

}
