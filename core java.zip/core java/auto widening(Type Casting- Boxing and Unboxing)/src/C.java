
class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		short i=20;
		double d=i;
		System.out.println("done");

	}

}
