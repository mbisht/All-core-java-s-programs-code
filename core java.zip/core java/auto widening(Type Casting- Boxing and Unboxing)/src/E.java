
class E {
	static void test(double d)
	{
		System.out.println("test(double)");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=100;
		test(i);
		System.out.println("done");

	}

}
