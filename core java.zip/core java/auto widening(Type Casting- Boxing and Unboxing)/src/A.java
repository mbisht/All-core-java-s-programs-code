
class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=10;
		double d=i;
		System.out.println("done");

	}

}
