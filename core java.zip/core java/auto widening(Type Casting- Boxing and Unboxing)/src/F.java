
class F {
	static double test()
	{
		int i=10;
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("done");

	}

}
