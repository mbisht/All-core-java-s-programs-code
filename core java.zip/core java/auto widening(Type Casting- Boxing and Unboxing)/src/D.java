
class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=20;
		float f=i;
		System.out.println("done");

	}

}
