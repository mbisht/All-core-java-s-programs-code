
class C {
	
	int i=10;

}
