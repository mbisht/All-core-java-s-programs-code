package pack1;

class G {
	int i=30;

}
