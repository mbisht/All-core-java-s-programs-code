package pack1;

public class I {
	public int x=40;

}
