package pack1;
class E
{
	int i=20;
}
class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		E e1=new E();
		System.out.println(e1.i);

	}

}
