package pack1;

class H {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		G g1=new G();
		System.out.println(g1.i);

	}

}
