package pack3;
import pack1.I;

class N {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I obj=new I();
		System.out.println(obj.x);

	}

}
