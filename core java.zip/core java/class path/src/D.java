
class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C c1=new C();
		System.out.println(c1.i);

	}

}
