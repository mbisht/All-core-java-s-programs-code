package pack2;

class K {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pack1.I obj1=new pack1.I();
		System.out.println(obj1.x);

	}

}
