package pack2;
import pack1.*;
class M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I obj1=new I();
		System.out.println(obj1.x);

	}

}
