package pack2;

class J {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		I obj1=new I();
		System.out.println(obj1.x);

	}

}
