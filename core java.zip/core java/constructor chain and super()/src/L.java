
class L 
{
	L()
	{
		super();
		System.out.println("L()");
		this(10);
	}
	L(int i)
	{
		super();
		System.out.println("L(int)");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("done");

	}

}
