
class J
{
	J()
	{
		System.out.println("J()");
	}
}
class K1 extends J
{
	K1()
	{
		System.out.println("K1()");
		super();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("done");

	}

}
