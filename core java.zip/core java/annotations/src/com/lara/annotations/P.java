package com.lara.annotations;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.SOURCE)
@interface Anno5
{
	public int countValue();
}

class P {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");


	}

}
/*
RetentionPolicy
----------
CLASS(Annotations are to be recorded in the class file by
the compiler but need not be retained by the VM at run 
time.)
RUNTIME(Annotations are to be recorded in the class file
by the compiler and retained by the VM at run time, so
they may be read reflectively.)
SOURCE(Annotations are to be discarded by the 
compiler.)
*/
