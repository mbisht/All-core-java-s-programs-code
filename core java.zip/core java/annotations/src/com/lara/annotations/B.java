package com.lara.annotations;

class B {

}
interface C
{
	
}
enum D
{
	
}
@interface E
{
	
}
