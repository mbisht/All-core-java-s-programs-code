package com.lara.annotations;
@interface M
{
	public String message();
	public boolean flag();
}
@M(message="some info")
class K {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");

	}

}
