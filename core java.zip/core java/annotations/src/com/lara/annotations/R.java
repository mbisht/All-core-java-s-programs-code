package com.lara.annotations;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(value=RetentionPolicy.RUNTIME)
abstract@interface Person
{
	public abstract String personFirstName();
	public abstract String personLastName();
	public abstract String personEmailId();
	public abstract String personAddress()
	default "Bangalore";
	public abstract int personAge()
	default 23;
}
@Person(personFirstName="ABC",
		personLastName="XYZ",
		personEmailId="abcxyz@laratechnology.com",
		personAddress="Bangalore",
		personAge=23) 

public class RPersonTestAnnotation 
{

}

