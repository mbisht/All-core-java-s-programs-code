package com.lara.annotations;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
@Target(ElemetType.FIELD)
@interface Ann4
{
	public String someMessage();
}

class O {
	@Ann4(someMessage="hello")


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");


	}

}
/*
ElementType
--------
CONSTRUCTOR(Constructor declaration)
FIELD(Field declaration (includes enum constants))
LOCAL_VARIABLE(Local variable declaration)
METHOD(Method declaration)
PACKAGE(Package declaration)
PARAMETER(Parameter declaration)
TYPE(Class, interface (including annotation type), or enum
declaration)
*/