package com.lara.annotations;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
@Target(ElemetType.METHOD)
@interface Ann3
{
	public String someMessage(); 
	
}

class N {
	@Ann3(someMessage="hello")

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");


	}

}
