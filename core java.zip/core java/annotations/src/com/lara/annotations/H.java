package com.lara.annotations;
@interface SomeInfo
{
	public String someMessage();
}
@SomeInfo(someMessage="some desc")
class H {
	
	@SomeInfo(someMessage="about i")
	int i;
	@SomeInfo(someMessage="about con")
	H()
	{
		
	}
	@SomeInfo(someMessage="about main")

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello World!");

	}

}
