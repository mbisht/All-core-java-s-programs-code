package com.lara.annotations;

@interface A {

}
