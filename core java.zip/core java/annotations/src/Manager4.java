import java.util.ArrayList;
class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList list=new ArrayList();
		list.add(90);
		list.add(90);
		System.out.println("done");
	}

}
