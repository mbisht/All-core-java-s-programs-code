
class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread t1=new Thread();
		t1.stop();
		System.out.println("done");

	}

}
