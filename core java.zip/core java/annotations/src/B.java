
class B extends A{
	@Override
	void test1()
	{
		System.out.println("B-test1");

	}
	void test2()
	{
		System.out.println("B-test2");
	
	}

}
