
class A {
	void test1()
	{
		System.out.println("A-test1");

	}

}
