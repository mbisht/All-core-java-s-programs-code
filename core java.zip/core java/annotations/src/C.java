
class C {
	@Deprecated
	void test1()
	{
		//some content
	}
	void test2()
	{
		//again some content
	}

}
