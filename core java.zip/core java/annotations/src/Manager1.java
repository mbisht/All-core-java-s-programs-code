
class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C c1=new C();
		c1.test1();
		c1.test2();
		System.out.println("done");
	}

}
