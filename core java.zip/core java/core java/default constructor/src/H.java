
class H {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		H h1=new H();
		System.out.println("done");

	}

}
