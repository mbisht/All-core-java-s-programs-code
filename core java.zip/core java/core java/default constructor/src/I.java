
class I {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		I obj=new I(90);
		System.out.println("done");

	}

}
