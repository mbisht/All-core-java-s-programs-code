enum E
{
	C1,C2,C3,C4;
}
class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(E.C1);
		System.out.println(E.C3);

	}

}
