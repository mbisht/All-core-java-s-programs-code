
enum V
{
	C1,C2,C3;
	V()
	{
		System.out.println("V()");
	}
}
class W {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		V v1=V.C3;
		System.out.println(v1);

	}

}
