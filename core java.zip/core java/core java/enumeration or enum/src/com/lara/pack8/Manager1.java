package com.lara.pack8;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread.State states[]=Thread.State.values();
		for(Thread.State state:states)
		{
			System.out.println(state);
		}

	}

}
