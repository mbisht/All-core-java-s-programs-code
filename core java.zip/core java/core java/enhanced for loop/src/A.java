
class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] x={10,20,30};
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]);
		}
	}

}
