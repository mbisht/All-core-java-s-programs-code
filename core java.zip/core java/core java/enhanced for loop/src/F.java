
class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] x={2,1,4,2,5,7,3,6,9};
		for(int i: x)
		{
			System.out.println(i);
		}
		System.out.println("----");
		for(int i=2;i<6;i++)
		{
			System.out.println(x[i]);
		}

	}

}
