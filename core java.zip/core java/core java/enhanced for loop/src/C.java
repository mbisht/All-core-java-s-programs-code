
class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[]x={1,20,30,40,50};
		for(int i:x)
		{
			System.out.println(i);
		}

	}

}
