
class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] x={
				"abc","xyz","hello","test","java"};
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]);
		}

	}

}
