
class E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double[] arr={10.9,8.9,0.1,6.7};
		for(double d1:arr)
		{
			System.out.println(d1);
		}

	}

}
