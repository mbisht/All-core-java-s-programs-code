
class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] x={
				"abc1","abc2","abc3","abc4","abc5","abc6","abc7"};
				for(String s1:x)
				{
					System.out.println(s1);
		        }

	}

}
