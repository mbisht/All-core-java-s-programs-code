
class R {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("R-main");

	}
	static
	{
		System.out.println("R-SIB");
	}

}
class S extends R
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("S-main");

	}
	static
	{
		System.out.println("S-SIB");
	}
	
}
class T extends S
{
	static
	{
		System.out.println("T-SIB");	
	}
}
class U {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("U-main-b");
		T.main(args);//S.main(args);
		System.out.println("U-main-e");

	}
	static
	{
		System.out.println("U-SIB");
	}
	}
