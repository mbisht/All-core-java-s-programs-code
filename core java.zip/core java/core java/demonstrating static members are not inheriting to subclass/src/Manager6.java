
class L
{
	static int i;
	static
	{
		System.out.println("from L-SIB");
	}
}
class M extends L
{
	static
	{
		System.out.println("from M-SIB");
	}
}
class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("-----");
		System.out.println(M.i); //L.i
		System.out.println("-----");

	}

}
