
class J
{
	static void test()
	{
		System.out.println("from J");
	}
	static
	{
		System.out.println("SIB-J");
	}
}
class K extends J
{
	static
	{
		System.out.println("SIB-K");
	}
}
class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		K.test(); //J.test();

	}

}
