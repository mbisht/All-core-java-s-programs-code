
class N {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("from N");
	}
	static
	{
		System.out.println("SIB-N");

	}

}
class O extends N
{
	static
	{
		System.out.println("SIB-O");
	}
}
