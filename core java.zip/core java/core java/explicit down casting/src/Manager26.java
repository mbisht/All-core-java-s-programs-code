
class Manager26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new B();//upcasting
		B b1=(B) a1;
		System.out.println("----");
		A a2=new A();//no casting at all
		B b2=(B) a2;
		
	}

}
