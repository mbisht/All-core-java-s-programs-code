
class Manager18 {
	static void test1(B b1)
	{
		System.out.println("from test1(B)");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new B();
		test1(a1);
		System.out.println("done");
	
	}

}
