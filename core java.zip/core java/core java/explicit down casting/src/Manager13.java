
class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new B();
		B b1=a1;
		System.out.println("done");

	}

}
