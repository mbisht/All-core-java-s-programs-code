
class Manager15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1=new D();
		C c1=b1;
		System.out.println("done");


	}

}
