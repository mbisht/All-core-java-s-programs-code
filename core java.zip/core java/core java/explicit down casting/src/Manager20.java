
class Manager20 {
	static C test()
	{
		A a1=new D();
		return a1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		D d1=test();
		System.out.println("done");

	}

}
