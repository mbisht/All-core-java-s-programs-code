
class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new B();
		B b1=(B) a1;
		System.out.println("done");

	}

}
