
class Manager25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new C();
		System.out.println(11);
		B b1=(B) a1;
		System.out.println(22);
		C c1=(C) a1;
		System.out.println(33);
		D d1=(D) a1;
		System.out.println(44);

	}

}
