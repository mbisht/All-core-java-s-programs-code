
class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1=new D();
		C c1=(C) b1;
		System.out.println("Hello World!");

	}

}
