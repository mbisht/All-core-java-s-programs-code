
interface M1 {
	public static final int REDUCTION=10;
	int j=20;
	String k="hello";

}
