
class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int i;
		i=10;
		System.out.println(i);
		//i=10;
		System.out.println(i);

	}

}
