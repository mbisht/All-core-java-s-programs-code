
class A1 {
	static final int i=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);

	}

}
