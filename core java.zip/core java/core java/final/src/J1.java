
class J1 {
	static final int CON=10;
	static final String DRIVER="some driver"; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(CON);
		System.out.println(DRIVER);

	}

}
