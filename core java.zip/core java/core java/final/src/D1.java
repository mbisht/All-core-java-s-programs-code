
class D1 {
	static final int i;

}
