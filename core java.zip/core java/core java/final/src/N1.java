
interface N1 
{
	int i;

}
