
class F1 {
	static final int i=10;
	static
	{
		i=10;
	}

}
