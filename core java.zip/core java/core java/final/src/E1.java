
class E1 {
	static final int i;
	static
	{
		i=10;
	}

}
