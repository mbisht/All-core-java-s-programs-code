
class K1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);

	}

}
