
class I1 {
	static final int x=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(x);
		System.out.println(x);
		System.out.println(x);

	}

}
