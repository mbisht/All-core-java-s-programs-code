
class B1 {
	static final int i=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(i);
		i=10;
		System.out.println(i);

	}

}
