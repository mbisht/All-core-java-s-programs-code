
class C1 {
	static final int i=10;
	void test()
	{
		i=10;
	}

}
