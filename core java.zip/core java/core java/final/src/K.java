
class K {
	public static void test(int i, final int j)
	{
		i=10;
		j=10;
		System.out.println(i);
		System.out.println(j);
	}

}
