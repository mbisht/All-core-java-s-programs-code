
class Y {
	final int i;
	Y()
	{
		i=10;
		
	}
	Y(int i)
	{
		i=10;
	}

}
