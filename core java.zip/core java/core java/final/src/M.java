
class M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		args=null;
		System.out.println("done");

	}

}
