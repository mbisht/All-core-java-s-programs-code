
class Z5 {
	final int i;
	Z5()
	{
		i=10;
	}
	{
		i=10;
	}

}
