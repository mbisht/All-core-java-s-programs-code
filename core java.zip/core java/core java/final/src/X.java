
class X {
	final int i;
	X()
	{
		i=0;
	}
	X(int j)
	{
		final int l;
		Y()
		{
			l=10;
		}
		Y(int i)
		{
			i=10;
		}
	}

}
