
class O {
	final int i=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		O o1=new O();
		o1.i=10;
		System.out.println(o1.i);

	}

}
