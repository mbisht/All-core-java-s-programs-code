
class G {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final String s1="abc";
		s1="abc";
		System.out.println("done");

	}

}
