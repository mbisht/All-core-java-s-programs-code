
class E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final [e]=new E();
		e1=null;
		System.out.println("done");

	}

}
