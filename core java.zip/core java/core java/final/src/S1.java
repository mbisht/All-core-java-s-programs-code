
abstract class S1 {
	abstract static void test();

}
