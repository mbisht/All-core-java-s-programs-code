
interface O1 
{
	int I=10;
	static int J=10;
	public static int K=10;
	public final static int L=10;
	public static final int M=10;
	static public final int X=10;
	

}
