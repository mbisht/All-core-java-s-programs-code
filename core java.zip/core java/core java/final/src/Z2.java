
class Z2 {
	final int i;
	{
		i=10;
	}

}
