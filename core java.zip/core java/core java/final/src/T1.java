
interface T1 {
	static void test1();

}
