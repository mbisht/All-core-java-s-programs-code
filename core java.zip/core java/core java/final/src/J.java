
class J {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final String[] y=new String[3];
		y=new String[3];
		System.out.println("done");

	}

}
