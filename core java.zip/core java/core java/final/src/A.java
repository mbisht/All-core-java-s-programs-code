
class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int i=10;
		int j=20;
		System.out.println(i);
		System.out.println(j);
		System.out.println("------");
		System.out.println(i);
		System.out.println(j);
		System.out.println("------");
		i=10;
		j=20;
		System.out.println(i);
		System.out.println(j);

	}

}
