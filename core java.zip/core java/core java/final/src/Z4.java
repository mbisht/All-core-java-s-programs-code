
class Z4 {
	final int i=10;
	{
		i=10;
	}

}
