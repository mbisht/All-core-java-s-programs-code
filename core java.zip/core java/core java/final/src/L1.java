
class L1 {
	static final int MAX_REDUCTION=10;	
	final static String COUNTRY_NAME="India";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(MAX_REDUCTION);
		System.out.println(COUNTRY_NAME);

	}

}
