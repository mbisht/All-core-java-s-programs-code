
class V {
	final int i;
	V()
	{
		i=0;
	}

}
