
class I {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int[] x=new int[3];
		x=null;
		System.out.println("done");

	}

}
