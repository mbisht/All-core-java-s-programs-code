
class U {
	final int x=0;

}
