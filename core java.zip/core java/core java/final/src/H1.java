
class H1 {
	final int i;
	H1()
	{
		i=10;
	}
	H1(double j)
	{
		i=20;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		H1 h1=new H1();
		H1 h2=new H1(90.90);
		System.out.println(h1.i);
		System.out.println(h2.i);

	}

}
