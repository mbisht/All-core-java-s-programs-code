
class Z1 {
	final int i;
	Z1()
	{
		i=10;
	}
	Z1(int i)
	{
		this.i=i;
	}

}
