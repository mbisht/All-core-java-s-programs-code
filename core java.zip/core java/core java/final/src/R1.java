
abstract class R1 {
	abstract final void test();

}
