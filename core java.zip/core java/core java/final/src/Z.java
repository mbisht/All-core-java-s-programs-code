
class Z {
	final int i;
	Z()
	{
		i=10;
	}
	Z(int j)
	{
		i=10;
	}

}
