
class Q {
	final int i=10;
	void test()
	{
		i=10;
	}

}
