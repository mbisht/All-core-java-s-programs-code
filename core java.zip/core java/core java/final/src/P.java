
class P {
	int i=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final P p1=new P();
		p1.i=10;
		System.out.println("done");

	}

}
