
class S {
	final int x=10;
	{
		x=10;
	}

}
