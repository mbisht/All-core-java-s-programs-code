
class G1 {
	static final int i;
	static
	{
		i=10;
	}
	static
	{
		i=10;
	}

}
