
class Z3 {
	final int l;
	{
		i=20;
	}
	{
		l=10;
	}

}
