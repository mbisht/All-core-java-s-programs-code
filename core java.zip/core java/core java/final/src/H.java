
class H {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int[] x=new int[2];
		x[0]=100;
		x[1]=200;
		System.out.println("done");

	}

}
