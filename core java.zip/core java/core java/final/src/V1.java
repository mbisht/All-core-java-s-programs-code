
final class U
{
	
}
class V1 extends U{

}
