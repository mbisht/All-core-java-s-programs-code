
class H {
	static
	{
		System.out.println("H-SIB");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("H-main");

	}

}
class I
{
	static
	{
		System.out.println("I-SIB");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("I-main");

	}
}
