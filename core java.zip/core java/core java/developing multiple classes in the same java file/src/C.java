
enum B
{
	
}
class C {

}
interface D
{
	
}
