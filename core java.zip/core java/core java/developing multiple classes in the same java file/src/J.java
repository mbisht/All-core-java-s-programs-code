
class J {
	static
	{
		System.out.println("J-SIB1");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("J-main");
	}
	static
	{
		System.out.println("J-SIB2");
	}

}

class K {
	static
	{
		System.out.println("K-SIB1");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("K-main");
	}
	static
	{
		System.out.println("K-SIB2");
	}

}
