
class A
{
	static int i;
}
class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(A.i);

	}

}
