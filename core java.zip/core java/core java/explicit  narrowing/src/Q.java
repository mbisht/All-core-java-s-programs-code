
class Q {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1=12.9;
		int i=(int)d1;
		System.out.println(d1);
		System.out.println(i);
	}

}