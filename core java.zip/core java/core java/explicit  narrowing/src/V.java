
class V {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1=10.90;
		long lon=(int)d1;
		System.out.println("done");

	}

}
