
class P {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1=10.9;
		int i=d1;
		System.out.println("done");

	}

}
