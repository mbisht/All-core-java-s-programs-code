
class U {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=10;
		short s=(byte)i;
		System.out.println("done");

	}

}
