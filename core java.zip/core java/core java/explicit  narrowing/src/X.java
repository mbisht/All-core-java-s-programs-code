
class X {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1=10.90;
		System.out.println(test((short)(byte)d1));
	}
	static double test(int i)
	{
		return i;

	}

}
