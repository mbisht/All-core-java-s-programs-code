
class W {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d1=10.9090;
		int i=(byte)(short)(int)d1;
		System.out.println(i);

	}

}
