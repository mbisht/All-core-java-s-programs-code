
class G {
	G()
	{
		System.out.println("G()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		G g1=new G(90);
		System.out.println("done");

	}

}
