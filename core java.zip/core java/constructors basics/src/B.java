
class B {
	B()
	{
		System.out.println("B()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b1=new B();
		System.out.println("------");
		B b2=new B();
		System.out.println("------");

	}

}
