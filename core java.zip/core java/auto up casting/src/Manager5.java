
class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new B();
		B b1=new C();
		C c1=new D();
		Object o1=new A();
		System.out.println("done");

	}

}
