
class Manager10 {
	static C test()
	{
		D d1=new D();
		return d1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new A();
		System.out.println("done");

	}

}
