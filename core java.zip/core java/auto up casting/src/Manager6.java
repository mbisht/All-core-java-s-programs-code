
class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new C();
		Object o1=new D();
		B b1=new C();
		C c1=new D();
		B b2=new D();
		Object o2=new C();
		System.out.println("done");

	}

}
