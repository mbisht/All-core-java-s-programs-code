
class Manager9 {
	static Object test1()
	{
		D d1=new D();
		return d1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object obj=test1();
		System.out.println("done");

	}

}
