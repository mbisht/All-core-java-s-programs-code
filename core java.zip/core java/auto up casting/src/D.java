
class D extends C{

}
