
class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object obj=new Object();
		A a1=new A();
		B b1=new B();
		C c1=new C();
		D d1=new D();
		System.out.println("done");

	}

}
