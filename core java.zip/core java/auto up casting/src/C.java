
class C extends B{

}
