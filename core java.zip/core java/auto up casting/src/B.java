
class B extends A{

}
